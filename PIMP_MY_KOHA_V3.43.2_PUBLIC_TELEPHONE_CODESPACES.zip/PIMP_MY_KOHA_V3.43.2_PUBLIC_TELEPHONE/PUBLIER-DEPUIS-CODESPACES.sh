#!/usr/bin/env bash

VERSION="3.43.2"
EXPECTED_REPOSITORY="Mikiflex83/PimpMyKoha"
TARGET_DIR="/workspaces/PimpMyKoha"
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)/payload"
DELIVERY_ZIP="PIMP_MY_KOHA_V3.43.2_PUBLIC_TELEPHONE_CODESPACES.zip"

fail() {
  printf '\nERREUR : %s\nLe dépôt n’a pas été publié. Le terminal peut rester ouvert.\n' "$1" >&2
  exit 1
}

printf '\n1/7 - Vérification du dépôt…\n'
test -d "$TARGET_DIR/.git" || fail "dépôt $TARGET_DIR introuvable"
test -f "$SOURCE_DIR/FULL-DIST/kohatools/loader.js" || fail "contenu de la livraison introuvable"

REMOTE_URL="$(git -C "$TARGET_DIR" remote get-url origin 2>/dev/null)" || fail "remote origin introuvable"
case "$REMOTE_URL" in
  "https://github.com/$EXPECTED_REPOSITORY"|"https://github.com/$EXPECTED_REPOSITORY.git"|"git@github.com:$EXPECTED_REPOSITORY.git") ;;
  *) fail "ce script est limité au dépôt $EXPECTED_REPOSITORY" ;;
esac

DIRTY="$(git -C "$TARGET_DIR" status --porcelain | sed "/$DELIVERY_ZIP$/d")"
test -z "$DIRTY" || fail "le dépôt contient déjà des modifications ; envoyez une capture de git status --short"

printf '2/7 - Mise à jour de main…\n'
git -C "$TARGET_DIR" switch main || fail "impossible de sélectionner main"
git -C "$TARGET_DIR" pull --ff-only origin main || fail "git pull a échoué"

printf '3/7 - Installation des fichiers 3.43.2…\n'
cp -a "$SOURCE_DIR/." "$TARGET_DIR/" || fail "copie des fichiers impossible"

printf '4/7 - Contrôles automatiques…\n'
cd "$TARGET_DIR" || fail "impossible d’ouvrir le dépôt"
node scripts/validate-dist.mjs --expected="$VERSION" || fail "validation de la distribution échouée"
node scripts/test-channel-loader.mjs || fail "test des canaux échoué"
node scripts/test-access-control.mjs || fail "test des accès échoué"
node scripts/test-navigation.mjs || fail "test de navigation échoué"
node scripts/test-fresh-install-canary.mjs || fail "test des candidates historiques échoué"
git diff --check || fail "contrôle Git échoué"

printf '5/7 - Commit et envoi sur GitHub…\n'
git add .github FULL-DIST docs install release scripts README.md LICENSE .gitignore || fail "git add a échoué"
if git diff --cached --quiet; then
  printf 'La version est déjà appliquée dans le dépôt.\n'
else
  git commit -m "Publish Pimp My Koha $VERSION" || fail "git commit a échoué"
fi
git push origin main || fail "git push a échoué"

printf '6/7 - Création de la release…\n'
if gh release view "v$VERSION" --repo "$EXPECTED_REPOSITORY" >/dev/null 2>&1; then
  printf 'La release v%s existe déjà.\n' "$VERSION"
else
  gh release create "v$VERSION" --repo "$EXPECTED_REPOSITORY" --target main --title "Pimp My Koha $VERSION" --notes "Navigation fiable, modules bloqués masqués, Centre qualité cohérent et test local sécurisé des candidates historiques en installation neuve." || fail "création de la release échouée"
fi

printf '7/7 - Terminé.\n\n'
printf 'PUBLICATION TERMINÉE\n'
printf 'Dépôt  : https://github.com/%s\n' "$EXPECTED_REPOSITORY"
printf 'Release: https://github.com/%s/releases/tag/v%s\n' "$EXPECTED_REPOSITORY" "$VERSION"
printf 'Attendez le succès des Actions GitHub avant de passer la sandbox sur 3.43.2.\n'
